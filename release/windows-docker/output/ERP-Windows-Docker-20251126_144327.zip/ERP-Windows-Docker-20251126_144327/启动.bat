@echo off
echo 启动ERP系统...
docker-compose start
docker-compose ps
echo.
echo 系统已启动！
echo 访问: http://localhost
pause
