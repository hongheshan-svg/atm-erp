from django.apps import AppConfig


class MasterdataConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.masterdata'
    verbose_name = '基础数据'

