@echo off
chcp 65001 >nul
echo ========================================
echo   ERP系统 Docker部署
echo ========================================
echo.

echo 1. 检查Docker是否安装...
docker --version >nul 2>&1
if errorlevel 1 (
    echo Docker未安装！
    echo 请先安装Docker Desktop for Windows
    echo 下载地址: https://www.docker.com/products/docker-desktop
    pause
    exit /b 1
)
echo ✓ Docker已安装
echo.

echo 2. 检查.env配置文件...
if not exist .env (
    echo 未找到.env文件，正在从.env.example创建...
    copy .env.example .env
    echo.
    echo ⚠ 重要: 请编辑.env文件修改默认密码！
    echo.
    pause
)
echo ✓ 配置文件存在
echo.

echo 3. 启动Docker服务...
docker-compose up -d
echo.

echo 4. 等待服务启动（30秒）...
timeout /t 30 /nobreak >nul
echo.

echo 5. 执行数据库迁移...
docker-compose exec -T backend python manage.py migrate
echo.

echo 6. 收集静态文件...
docker-compose exec -T backend python manage.py collectstatic --noinput
echo.

echo 7. 创建超级管理员...
docker-compose exec backend python manage.py createsuperuser
echo.

echo ========================================
echo   ✓ 部署完成！
echo ========================================
echo.
echo 访问地址:
echo   前端: http://localhost
echo   API:  http://localhost/api
echo   后台: http://localhost/admin
echo.
echo 管理命令:
echo   启动: docker-compose start
echo   停止: docker-compose stop
echo   重启: docker-compose restart
echo   日志: docker-compose logs -f
echo.
pause
