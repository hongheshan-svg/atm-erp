========================================
  ERP系统 Windows Docker部署包
========================================

系统要求:
---------
- Windows Server 2016+ 或 Windows 10/11 Pro
- 8GB+ 内存
- 100GB+ 磁盘空间
- Docker Desktop for Windows

快速开始:
---------
1. 安装Docker Desktop
   下载: https://www.docker.com/products/docker-desktop

2. 双击运行"部署.bat"

3. 按提示创建管理员账号

4. 访问 http://localhost

管理命令:
---------
- 启动.bat      : 启动系统
- 停止.bat      : 停止系统
- 重启.bat      : 重启系统
- 查看日志.bat  : 查看日志
- 备份数据.bat  : 备份数据

或使用命令行:
-------------
docker-compose up -d      # 启动
docker-compose stop       # 停止
docker-compose restart    # 重启
docker-compose logs -f    # 查看日志
docker-compose ps         # 查看状态

配置说明:
---------
安装前请编辑.env文件，修改:
- 数据库密码
- Redis密码  
- Django SECRET_KEY
- ALLOWED_HOSTS

技术支持:
---------
详细文档请查看docs目录

========================================
