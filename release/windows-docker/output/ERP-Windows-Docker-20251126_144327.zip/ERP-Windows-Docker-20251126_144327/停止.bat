@echo off
echo 停止ERP系统...
docker-compose stop
echo.
echo 系统已停止！
pause
