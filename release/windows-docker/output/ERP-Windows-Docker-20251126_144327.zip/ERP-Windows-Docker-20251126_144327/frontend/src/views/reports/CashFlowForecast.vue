<template>
  <div class="cash-flow-forecast">
    <el-card>
      <template #header>
        <div class="card-header">
          <span>现金流预测</span>
          <div class="header-actions">
            <el-radio-group v-model="forecastPeriod" @change="handlePeriodChange">
              <el-radio-button label="30">30天</el-radio-button>
              <el-radio-button label="60">60天</el-radio-button>
              <el-radio-button label="90">90天</el-radio-button>
            </el-radio-group>
            <el-button type="primary" @click="handleExport" style="margin-left: 15px;">
              <el-icon><Download /></el-icon>
              导出报表
            </el-button>
          </div>
        </div>
      </template>
      
      <!-- 现金流概览 -->
      <el-row :gutter="20" class="overview-row">
        <el-col :span="6">
          <el-card shadow="hover" class="stat-card current">
            <div class="stat-icon">
              <el-icon><Wallet /></el-icon>
            </div>
            <div class="stat-content">
              <div class="stat-value">¥{{ formatNumber(overview.currentBalance) }}</div>
              <div class="stat-label">当前现金余额</div>
            </div>
          </el-card>
        </el-col>
        <el-col :span="6">
          <el-card shadow="hover" class="stat-card inflow">
            <div class="stat-icon">
              <el-icon><Top /></el-icon>
            </div>
            <div class="stat-content">
              <div class="stat-value">¥{{ formatNumber(overview.expectedInflow) }}</div>
              <div class="stat-label">预计收款</div>
            </div>
          </el-card>
        </el-col>
        <el-col :span="6">
          <el-card shadow="hover" class="stat-card outflow">
            <div class="stat-icon">
              <el-icon><Bottom /></el-icon>
            </div>
            <div class="stat-content">
              <div class="stat-value">¥{{ formatNumber(overview.expectedOutflow) }}</div>
              <div class="stat-label">预计付款</div>
            </div>
          </el-card>
        </el-col>
        <el-col :span="6">
          <el-card shadow="hover" class="stat-card" :class="overview.netFlow >= 0 ? 'positive' : 'negative'">
            <div class="stat-icon">
              <el-icon><TrendCharts /></el-icon>
            </div>
            <div class="stat-content">
              <div class="stat-value">¥{{ formatNumber(overview.netFlow) }}</div>
              <div class="stat-label">净现金流</div>
            </div>
          </el-card>
        </el-col>
      </el-row>
      
      <!-- 现金流趋势图 -->
      <el-card shadow="never" class="chart-card">
        <template #header>现金流趋势预测</template>
        <div ref="trendChartRef" style="height: 350px;"></div>
      </el-card>
      
      <!-- 应收应付明细 -->
      <el-row :gutter="20" class="detail-row">
        <el-col :span="12">
          <el-card shadow="never">
            <template #header>
              <div class="detail-header">
                <span>应收账款计划</span>
                <el-tag type="success">预计收款: ¥{{ formatNumber(overview.expectedInflow) }}</el-tag>
              </div>
            </template>
            <el-table :data="arList" size="small" max-height="300">
              <el-table-column prop="customer_name" label="客户" min-width="120" />
              <el-table-column prop="invoice_no" label="发票号" width="120" />
              <el-table-column prop="due_date" label="到期日" width="100" />
              <el-table-column label="金额" width="120" align="right">
                <template #default="{ row }">
                  ¥{{ formatNumber(row.amount_due - row.amount_paid) }}
                </template>
              </el-table-column>
              <el-table-column label="状态" width="80">
                <template #default="{ row }">
                  <el-tag :type="getOverdueType(row.due_date)" size="small">
                    {{ getOverdueLabel(row.due_date) }}
                  </el-tag>
                </template>
              </el-table-column>
            </el-table>
          </el-card>
        </el-col>
        <el-col :span="12">
          <el-card shadow="never">
            <template #header>
              <div class="detail-header">
                <span>应付账款计划</span>
                <el-tag type="danger">预计付款: ¥{{ formatNumber(overview.expectedOutflow) }}</el-tag>
              </div>
            </template>
            <el-table :data="apList" size="small" max-height="300">
              <el-table-column prop="supplier_name" label="供应商" min-width="120" />
              <el-table-column prop="invoice_no" label="发票号" width="120" />
              <el-table-column prop="due_date" label="到期日" width="100" />
              <el-table-column label="金额" width="120" align="right">
                <template #default="{ row }">
                  ¥{{ formatNumber(row.amount_due - row.amount_paid) }}
                </template>
              </el-table-column>
              <el-table-column label="状态" width="80">
                <template #default="{ row }">
                  <el-tag :type="getOverdueType(row.due_date)" size="small">
                    {{ getOverdueLabel(row.due_date) }}
                  </el-tag>
                </template>
              </el-table-column>
            </el-table>
          </el-card>
        </el-col>
      </el-row>
      
      <!-- 资金缺口预警 -->
      <el-card shadow="never" class="alert-card" v-if="alerts.length > 0">
        <template #header>
          <span style="color: #f56c6c;">
            <el-icon><Warning /></el-icon>
            资金缺口预警
          </span>
        </template>
        <el-alert
          v-for="(alert, index) in alerts"
          :key="index"
          :title="alert.title"
          :description="alert.description"
          :type="alert.type"
          show-icon
          :closable="false"
          style="margin-bottom: 10px;"
        />
      </el-card>
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, onUnmounted } from 'vue'
import { ElMessage } from 'element-plus'
import { Download, Wallet, Top, Bottom, TrendCharts, Warning } from '@element-plus/icons-vue'
import request from '@/utils/request'
import * as echarts from 'echarts'

const forecastPeriod = ref('30')
const trendChartRef = ref(null)
let trendChart = null

const overview = reactive({
  currentBalance: 0,
  expectedInflow: 0,
  expectedOutflow: 0,
  netFlow: 0
})

const arList = ref([])
const apList = ref([])
const alerts = ref([])

const formatNumber = (num) => {
  if (!num) return '0.00'
  return Number(num).toLocaleString('zh-CN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
}

const getOverdueType = (dueDate) => {
  if (!dueDate) return 'info'
  const today = new Date()
  const due = new Date(dueDate)
  const diff = (due - today) / (1000 * 60 * 60 * 24)
  if (diff < 0) return 'danger'
  if (diff <= 7) return 'warning'
  return 'success'
}

const getOverdueLabel = (dueDate) => {
  if (!dueDate) return '未知'
  const today = new Date()
  const due = new Date(dueDate)
  const diff = Math.ceil((due - today) / (1000 * 60 * 60 * 24))
  if (diff < 0) return `逾期${Math.abs(diff)}天`
  if (diff === 0) return '今日到期'
  return `${diff}天后`
}

const fetchData = async () => {
  try {
    // 获取应收账款
    const arRes = await request.get('/finance/receivables/', {
      params: { status: 'PENDING', page_size: 100 }
    })
    arList.value = arRes.data?.results || arRes.results || arRes.data || []
    
    // 获取应付账款
    const apRes = await request.get('/finance/payables/', {
      params: { status: 'PENDING', page_size: 100 }
    })
    apList.value = apRes.data?.results || apRes.results || apRes.data || []
    
    calculateOverview()
    initTrendChart()
    checkAlerts()
  } catch (error) {
    console.error('获取数据失败:', error)
    // 使用模拟数据
    useMockData()
  }
}

const useMockData = () => {
  arList.value = [
    { id: 1, customer_name: '华为技术有限公司', invoice_no: 'INV-2024-001', due_date: '2024-12-15', amount_due: 150000, amount_paid: 50000 },
    { id: 2, customer_name: '腾讯科技有限公司', invoice_no: 'INV-2024-002', due_date: '2024-12-20', amount_due: 80000, amount_paid: 0 },
    { id: 3, customer_name: '阿里巴巴集团', invoice_no: 'INV-2024-003', due_date: '2025-01-05', amount_due: 200000, amount_paid: 100000 }
  ]
  
  apList.value = [
    { id: 1, supplier_name: '深圳供应商A', invoice_no: 'PINV-2024-001', due_date: '2024-12-10', amount_due: 50000, amount_paid: 0 },
    { id: 2, supplier_name: '广州供应商B', invoice_no: 'PINV-2024-002', due_date: '2024-12-25', amount_due: 30000, amount_paid: 10000 },
    { id: 3, supplier_name: '上海供应商C', invoice_no: 'PINV-2024-003', due_date: '2025-01-10', amount_due: 80000, amount_paid: 0 }
  ]
  
  overview.currentBalance = 500000
  calculateOverview()
  initTrendChart()
  checkAlerts()
}

const calculateOverview = () => {
  const days = parseInt(forecastPeriod.value)
  const endDate = new Date()
  endDate.setDate(endDate.getDate() + days)
  
  // 计算预计收款
  overview.expectedInflow = arList.value
    .filter(ar => new Date(ar.due_date) <= endDate)
    .reduce((sum, ar) => sum + (ar.amount_due - ar.amount_paid), 0)
  
  // 计算预计付款
  overview.expectedOutflow = apList.value
    .filter(ap => new Date(ap.due_date) <= endDate)
    .reduce((sum, ap) => sum + (ap.amount_due - ap.amount_paid), 0)
  
  // 净现金流
  overview.netFlow = overview.expectedInflow - overview.expectedOutflow
  
  if (!overview.currentBalance) {
    overview.currentBalance = 500000 // 默认余额
  }
}

const initTrendChart = () => {
  if (!trendChartRef.value) return
  
  if (trendChart) {
    trendChart.dispose()
  }
  
  trendChart = echarts.init(trendChartRef.value)
  
  // 生成预测数据
  const days = parseInt(forecastPeriod.value)
  const dates = []
  const balances = []
  const inflows = []
  const outflows = []
  
  let balance = overview.currentBalance
  const today = new Date()
  
  for (let i = 0; i <= days; i++) {
    const date = new Date(today)
    date.setDate(date.getDate() + i)
    const dateStr = date.toISOString().split('T')[0]
    dates.push(dateStr)
    
    // 计算当日收款
    const dayInflow = arList.value
      .filter(ar => ar.due_date === dateStr)
      .reduce((sum, ar) => sum + (ar.amount_due - ar.amount_paid), 0)
    
    // 计算当日付款
    const dayOutflow = apList.value
      .filter(ap => ap.due_date === dateStr)
      .reduce((sum, ap) => sum + (ap.amount_due - ap.amount_paid), 0)
    
    balance = balance + dayInflow - dayOutflow
    
    inflows.push(dayInflow)
    outflows.push(dayOutflow)
    balances.push(balance)
  }
  
  const option = {
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'cross'
      },
      formatter: (params) => {
        let result = params[0].axisValue + '<br/>'
        params.forEach(param => {
          result += `${param.marker} ${param.seriesName}: ¥${formatNumber(param.value)}<br/>`
        })
        return result
      }
    },
    legend: {
      data: ['现金余额', '收款', '付款']
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      data: dates,
      axisLabel: {
        rotate: 45
      }
    },
    yAxis: [
      {
        type: 'value',
        name: '金额 (元)',
        axisLabel: {
          formatter: (value) => {
            if (value >= 10000) return (value / 10000).toFixed(0) + '万'
            return value
          }
        }
      }
    ],
    series: [
      {
        name: '现金余额',
        type: 'line',
        data: balances,
        smooth: true,
        lineStyle: { width: 3 },
        areaStyle: {
          opacity: 0.3,
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: 'rgba(64, 158, 255, 0.5)' },
            { offset: 1, color: 'rgba(64, 158, 255, 0.1)' }
          ])
        },
        markLine: {
          data: [
            { yAxis: 0, lineStyle: { color: '#f56c6c' }, label: { formatter: '警戒线' } }
          ]
        }
      },
      {
        name: '收款',
        type: 'bar',
        data: inflows,
        itemStyle: { color: '#67c23a' }
      },
      {
        name: '付款',
        type: 'bar',
        data: outflows,
        itemStyle: { color: '#f56c6c' }
      }
    ]
  }
  
  trendChart.setOption(option)
}

const checkAlerts = () => {
  alerts.value = []
  
  // 检查资金缺口
  const projectedBalance = overview.currentBalance + overview.netFlow
  if (projectedBalance < 0) {
    alerts.value.push({
      type: 'error',
      title: '资金缺口预警',
      description: `预计${forecastPeriod.value}天后将出现资金缺口 ¥${formatNumber(Math.abs(projectedBalance))}，请及时安排资金调度。`
    })
  }
  
  // 检查逾期应收
  const overdueAR = arList.value.filter(ar => new Date(ar.due_date) < new Date())
  if (overdueAR.length > 0) {
    const overdueAmount = overdueAR.reduce((sum, ar) => sum + (ar.amount_due - ar.amount_paid), 0)
    alerts.value.push({
      type: 'warning',
      title: '应收账款逾期',
      description: `有${overdueAR.length}笔应收账款已逾期，逾期金额合计 ¥${formatNumber(overdueAmount)}，请及时催收。`
    })
  }
  
  // 检查即将到期的应付
  const urgentAP = apList.value.filter(ap => {
    const due = new Date(ap.due_date)
    const today = new Date()
    const diff = (due - today) / (1000 * 60 * 60 * 24)
    return diff >= 0 && diff <= 7
  })
  if (urgentAP.length > 0) {
    const urgentAmount = urgentAP.reduce((sum, ap) => sum + (ap.amount_due - ap.amount_paid), 0)
    alerts.value.push({
      type: 'warning',
      title: '应付账款即将到期',
      description: `有${urgentAP.length}笔应付账款将在7天内到期，金额合计 ¥${formatNumber(urgentAmount)}，请准备付款资金。`
    })
  }
}

const handlePeriodChange = () => {
  calculateOverview()
  initTrendChart()
  checkAlerts()
}

const handleExport = () => {
  if (!arList.value.length && !apList.value.length) {
    ElMessage.warning('没有数据可导出')
    return
  }
  
  // 生成导出数据
  const days = parseInt(forecastPeriod.value)
  const exportData = []
  let balance = overview.currentBalance
  const today = new Date()
  
  for (let i = 0; i <= days; i++) {
    const date = new Date(today)
    date.setDate(date.getDate() + i)
    const dateStr = date.toISOString().split('T')[0]
    
    const dayInflow = arList.value
      .filter(ar => ar.due_date === dateStr)
      .reduce((sum, ar) => sum + (ar.amount_due - ar.amount_paid), 0)
    
    const dayOutflow = apList.value
      .filter(ap => ap.due_date === dateStr)
      .reduce((sum, ap) => sum + (ap.amount_due - ap.amount_paid), 0)
    
    balance = balance + dayInflow - dayOutflow
    
    if (dayInflow > 0 || dayOutflow > 0) {
      exportData.push({
        date: dateStr,
        expected_inflow: dayInflow,
        expected_outflow: dayOutflow,
        net_flow: dayInflow - dayOutflow,
        cumulative_balance: balance
      })
    }
  }
  
  if (!exportData.length) {
    ElMessage.warning('所选时间范围内没有现金流数据')
    return
  }
  
  import('@/utils/export').then(({ exportToExcel: doExport, formatMoney }) => {
    const columns = [
      { field: 'date', title: '日期' },
      { field: 'expected_inflow', title: '预计流入', formatter: formatMoney },
      { field: 'expected_outflow', title: '预计流出', formatter: formatMoney },
      { field: 'net_flow', title: '净流量', formatter: formatMoney },
      { field: 'cumulative_balance', title: '累计余额', formatter: formatMoney }
    ]
    doExport(exportData, columns, '现金流预测')
    ElMessage.success('导出成功')
  })
}

onMounted(() => {
  fetchData()
  window.addEventListener('resize', () => {
    trendChart?.resize()
  })
})

onUnmounted(() => {
  trendChart?.dispose()
})
</script>

<style scoped>
.cash-flow-forecast {
  padding: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 16px;
  font-weight: bold;
}

.header-actions {
  display: flex;
  align-items: center;
}

.overview-row {
  margin-bottom: 20px;
}

.stat-card {
  display: flex;
  align-items: center;
  padding: 15px;
}

.stat-card.current {
  background: linear-gradient(135deg, #409eff 0%, #66b1ff 100%);
  color: white;
}

.stat-card.inflow {
  background: linear-gradient(135deg, #67c23a 0%, #85ce61 100%);
  color: white;
}

.stat-card.outflow {
  background: linear-gradient(135deg, #f56c6c 0%, #f78989 100%);
  color: white;
}

.stat-card.positive {
  background: linear-gradient(135deg, #67c23a 0%, #85ce61 100%);
  color: white;
}

.stat-card.negative {
  background: linear-gradient(135deg, #f56c6c 0%, #f78989 100%);
  color: white;
}

.stat-icon {
  font-size: 40px;
  margin-right: 15px;
  opacity: 0.8;
}

.stat-content {
  flex: 1;
}

.stat-value {
  font-size: 24px;
  font-weight: bold;
}

.stat-label {
  font-size: 14px;
  opacity: 0.9;
  margin-top: 5px;
}

.chart-card {
  margin-bottom: 20px;
}

.detail-row {
  margin-bottom: 20px;
}

.detail-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.alert-card {
  margin-top: 20px;
}
</style>

