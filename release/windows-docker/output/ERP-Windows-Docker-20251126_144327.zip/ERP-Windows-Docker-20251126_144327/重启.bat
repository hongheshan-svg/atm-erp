@echo off
echo 重启ERP系统...
docker-compose restart
docker-compose ps
echo.
echo 系统已重启！
pause
