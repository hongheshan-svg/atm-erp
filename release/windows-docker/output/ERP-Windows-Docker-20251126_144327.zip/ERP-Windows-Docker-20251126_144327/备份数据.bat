@echo off
echo 备份ERP系统数据...
set TIMESTAMP=%date:~0,4%%date:~5,2%%date:~8,2%_%time:~0,2%%time:~3,2%%time:~6,2%
set TIMESTAMP=%TIMESTAMP: =0%

if not exist backups mkdir backups

echo 备份数据库...
docker-compose exec -T db pg_dump -U erp_user erp_db > backups\db_%TIMESTAMP%.sql
echo ✓ 数据库已备份

echo 备份上传文件...
docker cp erp_backend:/app/media backups\media_%TIMESTAMP%
echo ✓ 上传文件已备份

echo.
echo 备份完成！
echo 数据库: backups\db_%TIMESTAMP%.sql
echo 文件: backups\media_%TIMESTAMP%
pause
